import React from 'react';
import ContactPage from './ContactPage';

const App = () => {
  return (
    <div className="App">
      <ContactPage />
    </div>
  );
};

export default App;